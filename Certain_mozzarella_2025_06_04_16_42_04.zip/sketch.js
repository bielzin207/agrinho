let truck, cityX = 800, crops = [];
function setup() {
 createCanvas(900, 400);
 truck = createVector(100, height / 2);
 for (let i = 0; i < 5; i++) {
 crops.push(createVector(random(200, 700), random(50, 350)));
 }
}
function draw() {
 background(180, 220, 140);
 fill(120);
 rect(cityX, 0, 100, height);
 fill(255, 0, 0);
 rect(truck.x, truck.y, 40, 20);

 for (let i = crops.length - 1; i >= 0; i--) {
 fill(0, 200, 0);
 ellipse(crops[i].x, crops[i].y, 20, 20);
 if (dist(truck.x, truck.y, crops[i].x, crops[i].y) < 20) {
 crops.splice(i, 1);
 }
 }
 if (truck.x > cityX) {
 fill(0);
 textSize(32);
 text("Entrega Concluída!", 300, 200);
 noLoop();
 }
}
function keyPressed() {
 if (keyCode === RIGHT_ARROW) truck.x += 10;
 if (keyCode === LEFT_ARROW) truck.x -= 10;
 if (keyCode === UP_ARROW) truck.y -= 10;
 if (keyCode === DOWN_ARROW) truck.y += 10;
}